package com.olympic.cis143.m04.student.homework.tacotruckmap.impl;

import com.olympic.cis143.m04.student.homework.tacotruckmap.OrderDoesNotExistException;
import com.olympic.cis143.m04.student.homework.tacotruckmap.Orders;
import com.olympic.cis143.m04.student.homework.tacotruckmap.TacoImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrdersMapImpl implements Orders {
	
	private Map<String, List<TacoImpl>> tacoOrders = new HashMap<>();
	
    @Override
    public void createOrder(final String orderid) {
    	this.tacoOrders.put(orderid, new ArrayList<TacoImpl>());
    }
    
    private void checkForOrder(final String orderid) throws OrderDoesNotExistException {
        if (this.tacoOrders.get(orderid) == null) {
            throw new OrderDoesNotExistException(orderid);
        }
    }
    @Override
    public void addTacoToOrder(final String orderid, final TacoImpl taco) throws OrderDoesNotExistException {
    	this.checkForOrder(orderid);
        this.tacoOrders.get(orderid).add(taco);
    }

    @Override
    public boolean hasNext() {
    	return !this.tacoOrders.isEmpty();
    }

    @Override
    public List<TacoImpl> closeOrder(final String orderid) throws OrderDoesNotExistException {
    	this.checkForOrder(orderid);
        return this.tacoOrders.remove(orderid);
    }

    @Override
    public int howManyOrders() {
    	return this.tacoOrders.size();
    }

    @Override
    public List<TacoImpl> getListOfOrders(final String orderid) throws OrderDoesNotExistException {
    	this.checkForOrder(orderid);
        return this.tacoOrders.get(orderid);
    }
}
