package com.olympic.cis143.m04.student.tacotruck.set;


import com.olympic.cis143.m04.student.tacotruck.Orders;
import com.olympic.cis143.m04.student.tacotruck.TacoImpl;
import java.util.HashSet;
import java.util.Set;

public class OrdersSetImpl  implements Orders {
	private Set<TacoImpl> orders = new HashSet<>();
    @Override
    public void addOrder(TacoImpl tacoOrder) {
    	
    	this.orders.add(tacoOrder);
    }

    @Override
    public boolean hasNext() {
    	
    	return !this.orders.isEmpty();
    }

    @Override
    public TacoImpl closeNextOrder() {
    	TacoImpl tacoOrder = (TacoImpl)(this.orders.toArray())[0];
        this.orders.remove(tacoOrder);
        return tacoOrder;
    }	

    @Override
    public int howManyOrders() {
    	return this.orders.size();
    }
}
