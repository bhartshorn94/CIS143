package BlackJack;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class BlackJack {
	/*I ended up using a console output to create a real interactive blackjack game in java. 
	 * This nullified the use case for creating a test class. I also simplified the game to be interactive with just the dealer and player.
	 * */
	
	public static void main(String[] args) {
		//Start Message
		System.out.println("BlackJack is the name of the Game: \n");
		
		//Initialize playing Decks
		Deck initialDeck = new Deck();
		initialDeck.createFullDeck();
		initialDeck.shuffle();
		
		//Create playerdeck
		Deck playerDeck = new Deck();
		Deck dealerDeck = new Deck();
		
		double playerPurse = 500.00;
		
		Scanner playerInput = new Scanner(System.in);
		
		//Initialize GamePlay and play until player is out of money in their purse
		
		while(playerPurse > 0)
		{
			System.out.println("Players Purse $:" + playerPurse + "\nEnter your bet:");
			double playerBet = playerInput.nextDouble();
			boolean endOfRound = false;
			//Check to see if player has enough money to continue
			if(playerBet > playerPurse)
			{
				System.out.println("Bet is greater than the amount you have in your purse");
				break;
			}
			//Deal
			//Deal player two cards
			playerDeck.draw(initialDeck);
			playerDeck.draw(initialDeck);
			
			//Deal two cards to dealer
			dealerDeck.draw(initialDeck);
			dealerDeck.draw(initialDeck);
			
			while(true)
			{
				System.out.println("Your Hand:");
				System.out.println(playerDeck.toString());
				System.out.println("Your hand is valued at: " + playerDeck.cardsValue());
				
				//Display Dealer Hand
				System.out.println("Dealer Hand:" + dealerDeck.get(0).toString() + "Dealers Second Card");
				
				//Ask player what to do next
				System.out.println("Would you like to (1) Hit or (2) Stay?");
				int response = playerInput.nextInt();
				
				//Player Hits
				if(response == 1)
				{
					playerDeck.draw(initialDeck);
					System.out.println("You draw a:" + playerDeck.get(playerDeck.deckSize()));
				}
				if(playerDeck.cardsValue() > 21)
				{
					System.out.println("Bust. Current hand: " + playerDeck.cardsValue());
					playerPurse -= playerBet;
					endOfRound = true;
					break;
				}
				if(response==2)
				{
					break;
				}
			}
			//Shows dealer Cards
			System.out.println("Dealer Cards: " + dealerDeck.toString());
			//Check to see if dealer has more points than player
			if(dealerDeck.cardsValue() > playerDeck.cardsValue() && endOfRound == false )
			{
				System.out.println("Dealer beats you!");
				playerPurse -= playerBet;
				endOfRound = true;
			}
			//Dealer draws at 16, stays at 17
			while((dealerDeck.cardsValue() < 17) && endOfRound == false)
			{
				dealerDeck.draw(initialDeck);
				System.out.println("Dealer Draws: " + dealerDeck.get(dealerDeck.deckSize()-1).toString());
			}
			//Display total value of dealers hand
			System.out.println("Dealers Hand total is: " + dealerDeck.cardsValue());
			if(dealerDeck.cardsValue() > 21 && endOfRound == false)
			{
				System.out.println("Dealer busts! Player Wins");
				playerPurse += playerBet;
				endOfRound = true;
			}
			
			//Determine if push
			if(playerDeck.cardsValue() == dealerDeck.cardsValue() && endOfRound ==false)
			{
				System.out.println("Push");
				endOfRound = true;
			}
			//Check to see if player wins
			if(playerDeck.cardsValue() > dealerDeck.cardsValue() && endOfRound == false)
			{
				System.out.println("You win the hand!!!!");
				playerPurse += playerBet;
				endOfRound = true;
				}
			//Clear decks of cards back to initial deck
			playerDeck.exodusCardsToDeck(initialDeck);
			dealerDeck.exodusCardsToDeck(initialDeck);
			
			System.out.println("End of Hand");
		}
		System.out.println("Game Over!!!!!!! You Lost... try again?");
		//Check to make is initilized correctly
		//System.out.println(initalDeck);
	}
	

}
