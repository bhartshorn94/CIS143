package BlackJack;
//Enumerate Suits to handle in Cards Class
//Module 2: enum is a type that can be used in an interface to set predefined constants to be handled outside of class scope
public enum Suit {
		CLUB, DIAMOND, SPADE, HEART
	}

