package BlackJack;

import java.util.ArrayList;
import java.util.Random;

public class Deck {
	//instance variables
	private ArrayList<Card> cards;
	//constructor
	public Deck() {
		this.cards = new ArrayList<Card>();
	}
	
	public void createFullDeck()
	{
		//Create Cards
		for(Suit cardSuit : Suit.values())
		{
			for(CardValues cardValues : CardValues.values())
			{
				//Add Cards to the deck
				this.cards.add(new Card(cardSuit,cardValues));
			}
		}
	}
	//Module 3 objective Arraylists: This shuffle class uses Arraylists to store cards in a temporary deck to then create a deck to be used in the game.
	public void shuffle()
	{
		//Create temporary deck to shuffle
		ArrayList<Card> tempDeck = new ArrayList<Card>();
		//Random method to shuffle
		Random random = new Random();
		
		int randomCardIndex = 0;
		int originalSize = this.cards.size();
		for(int i=0; i < originalSize; i++)
		{
			randomCardIndex = random.nextInt((this.cards.size()-1 - 0) + 1) + 0;
			tempDeck.add(this.cards.get(randomCardIndex));
			//Remove from original deck
			this.cards.remove(randomCardIndex);
		}
		this.cards = tempDeck;
	}
	public int deckSize()
	{
		return this.cards.size();
	}
	//Remove card from deck
	public void remove(int i)
	{
		this.cards.remove(i);
	}
	//Get Card from the deck
	public Card get(int i)
	{
		return this.cards.get(i);
	}
	//Add card to the deck
	public void add(Card addCard)
	{
		this.cards.add(addCard);
	}
	//Draws from the deck
	public void draw(Deck previousDeck)
	{
		this.cards.add(previousDeck.get(0));
		previousDeck.remove(0);
	}
	public void exodusCardsToDeck(Deck moveTo)
	{
		int thisDeckSize = this.cards.size();
		// Module 3 Iterators: Using a for loop to iterate through the deck using I as the countin variable
		//puts cards into moveTo deck
		for(int i = 0; i < this.deckSize(); i++)
		{
			moveTo.add(this.get(i));
		}
		for(int i = 0; i < thisDeckSize; i++)
		{
			this.remove(0);
		}
	}
	//Total up the sum of cards in deck specified
	public int cardsValue()
	{
		int sumValue = 0;
		int aces = 0;
		
		for(Card thisCard : this.cards)
		{
			switch(thisCard.getValue())
			{
			case TWO: sumValue += 2; break;
			case THREE: sumValue += 3; break;
			case FOUR: sumValue += 4; break;
			case FIVE: sumValue += 5; break;
			case SIX: sumValue += 6; break;
			case SEVEN: sumValue += 7; break;
			case EIGHT: sumValue += 8; break;
			case NINE: sumValue += 9; break;
			case TEN: sumValue += 10; break;
			case JACK: sumValue += 10; break;
			case QUEEN: sumValue += 10; break;
			case KING: sumValue += 10; break;
			case ACE: aces += 1; break;
			}
		}
		for(int i=0; i<aces; i++)
		{
			if(sumValue > 10)
			{
				sumValue += 1;
			}
			else {
				sumValue += 11;
			}
		}
		return sumValue;
	}
	public String toString() {
		String cardsAsList = "";
		int i = 0;
		for(Card thisCard : this.cards)
		{
			cardsAsList += "\n" + i + "-" + thisCard.toString(); 
			i++;
		}
		return cardsAsList;
	}
}
