package BlackJack;
// Create constructors and methods to handle Cards suits and values in the blackjack program
public class Card {

    private Suit suit;
    private CardValues value;

    public Card(Suit suit, CardValues value) {
        this.suit = suit;
        this.value = value;
    }
    public String toString()
    {
    	return this.suit.toString() + "-" + this.value.toString();
    }
    public CardValues getValue()
    {
    	return this.value;
    }
}
