package com.olympic.cis143.m05.student.homework.annotations2;

@FoodItem(type = "Taco")
public class Taco {
}
